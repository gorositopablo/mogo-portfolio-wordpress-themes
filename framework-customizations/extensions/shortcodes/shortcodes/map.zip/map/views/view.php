<?php
if (!defined('FW')) {
    die('Forbidden');
}

/**
 * @var $map_data_attr
 * @var $atts
 * @var $content
 * @var $tag
 */
?>
<!--<div class="mogo-map" <?php //echo mogo_attr_to_html($map_data_attr);  ?>>
    <div class="mogo-map-canvas"></div>
</div>-->

<script type="text/javascript">
    function showmap() {
        var mapOptions = {
            zoom: 8,
            scrollwheel: false,
            center: new google.maps.LatLng(-34.397, 150.644),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
    }
</script>


<div class="main_maps text-center">
    <div class="col-sm-12">

        <div class="map_canvas_icon">
            <i class="fa fa-map-marker" onClick="showmap()"></i>
            <h2 onClick="showmap()">Open map</h2>
        </div>
        <div id="map_canvas"></div>
    </div>
</div>
