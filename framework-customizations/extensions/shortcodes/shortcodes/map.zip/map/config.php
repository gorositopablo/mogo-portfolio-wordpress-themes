<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Map', 'getleads' ),
	'description' => __( 'Add a Map', 'getleads' ),
	'tab'         => __( 'Content Elements', 'getleads' )
);