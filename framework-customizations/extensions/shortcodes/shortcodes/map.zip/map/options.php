<?php

if (!defined('FW')) {
    die('Forbidden');
}

$map_shortcode = fw_ext('shortcodes')->get_shortcode('map');
$options = array(
    'data_provider' => array(
        'type' => 'multi-picker',
        'label' => false,
        'desc' => false,
        'picker' => array(
            'population_method' => array(
                'label' => __('Population Method', 'bt'),
                'desc' => __('Select map population method (Ex: events, custom)', 'bt'),
                'type' => 'select',
                'choices' => $map_shortcode->_get_picker_dropdown_choices(),
            )
        ),
        'choices' => $map_shortcode->_get_picker_choices(),
        'show_borders' => true,
    ),
   
    'map_height' => array(
        'label' => __('Map Height', 'bt'),
        'desc' => __('Set map height (Ex: 300)', 'bt'),
        'type' => 'text'
    )
);
